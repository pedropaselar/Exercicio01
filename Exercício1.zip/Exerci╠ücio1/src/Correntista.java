
public class Correntista {

	String cpf;
	String nome;
	Double saldo;
}
